package com.example.calculaterapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    TextView tvResult;
    String currentNumber = "";
    String operator = "";
    double firstNumber = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvResult = findViewById(R.id.tvResult);
    }

    // Number Button Click
    public void onNumberClick(View view) {
        Button button = (Button) view;
        currentNumber += button.getText().toString();
        tvResult.setText(currentNumber);
    }

    // Operator Button Click
    public void onOperatorClick(View view) {
        Button button = (Button) view;
        operator = button.getText().toString();
        firstNumber = Double.parseDouble(currentNumber);
        currentNumber = "";
    }

    // Equal Button Click
    public void onEqualClick(View view) {
        double secondNumber = Double.parseDouble(currentNumber);
        double result = 0;

        switch (operator) {
            case "+":
                result = firstNumber + secondNumber;
                break;
            case "-":
                result = firstNumber - secondNumber;
                break;
            case "*":
                result = firstNumber * secondNumber;
                break;
            case "/":
                if (secondNumber != 0)
                    result = firstNumber / secondNumber;
                else {
                    tvResult.setText("Error");
                    return;
                }
                break;
        }

        tvResult.setText(String.valueOf(result));
        currentNumber = String.valueOf(result);
    }

    // Clear Button Click
    public void onClearClick(View view) {
        currentNumber = "";
        operator = "";
        firstNumber = 0;
        tvResult.setText("0");
    }
}